<script setup>
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
</script>

<template>
    <div class="w-full p-2">Hola desde el componente</div>
</template>
